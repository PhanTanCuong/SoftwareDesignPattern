﻿namespace FactoryProject
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.AnimalcomboBox = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.usernametextBox = new System.Windows.Forms.TextBox();
            this.Createbutton = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.playertextBox = new System.Windows.Forms.TextBox();
            this.AnimaltextBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.QtextBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.PassivetextBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.EtextBox = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.WtextBox = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.DifficultytextBox = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.RtextBox = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.RoletextBox = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // AnimalcomboBox
            // 
            this.AnimalcomboBox.FormattingEnabled = true;
            this.AnimalcomboBox.Items.AddRange(new object[] {
            "Cat",
            "Dog",
            "Chicken",
            "Mouse",
            "Pig"});
            this.AnimalcomboBox.Location = new System.Drawing.Point(56, 171);
            this.AnimalcomboBox.Name = "AnimalcomboBox";
            this.AnimalcomboBox.Size = new System.Drawing.Size(150, 24);
            this.AnimalcomboBox.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Navy;
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label1.Location = new System.Drawing.Point(53, 130);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(191, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "Choose your animal champion:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Navy;
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label2.Location = new System.Drawing.Point(313, 130);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(176, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "Please writre your username";
            // 
            // usernametextBox
            // 
            this.usernametextBox.Location = new System.Drawing.Point(316, 173);
            this.usernametextBox.Name = "usernametextBox";
            this.usernametextBox.Size = new System.Drawing.Size(383, 22);
            this.usernametextBox.TabIndex = 3;
            // 
            // Createbutton
            // 
            this.Createbutton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.Createbutton.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Createbutton.ForeColor = System.Drawing.Color.DarkBlue;
            this.Createbutton.Location = new System.Drawing.Point(860, 150);
            this.Createbutton.Name = "Createbutton";
            this.Createbutton.Size = new System.Drawing.Size(124, 45);
            this.Createbutton.TabIndex = 4;
            this.Createbutton.Text = "PICK";
            this.Createbutton.UseVisualStyleBackColor = false;
            this.Createbutton.Click += new System.EventHandler(this.Createbutton_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.MidnightBlue;
            this.pictureBox1.Location = new System.Drawing.Point(509, 231);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(658, 347);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Navy;
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label3.Location = new System.Drawing.Point(53, 231);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 16);
            this.label3.TabIndex = 6;
            this.label3.Text = "Player:";
            // 
            // playertextBox
            // 
            this.playertextBox.Location = new System.Drawing.Point(166, 231);
            this.playertextBox.Name = "playertextBox";
            this.playertextBox.Size = new System.Drawing.Size(271, 22);
            this.playertextBox.TabIndex = 7;
            // 
            // AnimaltextBox
            // 
            this.AnimaltextBox.Location = new System.Drawing.Point(166, 267);
            this.AnimaltextBox.Name = "AnimaltextBox";
            this.AnimaltextBox.Size = new System.Drawing.Size(271, 22);
            this.AnimaltextBox.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Navy;
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label4.Location = new System.Drawing.Point(53, 267);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(108, 16);
            this.label4.TabIndex = 8;
            this.label4.Text = "Champion name:";
            // 
            // QtextBox
            // 
            this.QtextBox.Location = new System.Drawing.Point(166, 343);
            this.QtextBox.Name = "QtextBox";
            this.QtextBox.Size = new System.Drawing.Size(271, 22);
            this.QtextBox.TabIndex = 13;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Navy;
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label5.Location = new System.Drawing.Point(53, 343);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(58, 16);
            this.label5.TabIndex = 12;
            this.label5.Text = "Q ability:";
            // 
            // PassivetextBox
            // 
            this.PassivetextBox.Location = new System.Drawing.Point(166, 307);
            this.PassivetextBox.Name = "PassivetextBox";
            this.PassivetextBox.Size = new System.Drawing.Size(271, 22);
            this.PassivetextBox.TabIndex = 11;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Navy;
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label6.Location = new System.Drawing.Point(53, 307);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(59, 16);
            this.label6.TabIndex = 10;
            this.label6.Text = "Passive:";
            // 
            // EtextBox
            // 
            this.EtextBox.Location = new System.Drawing.Point(166, 423);
            this.EtextBox.Name = "EtextBox";
            this.EtextBox.Size = new System.Drawing.Size(271, 22);
            this.EtextBox.TabIndex = 17;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Navy;
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label7.Location = new System.Drawing.Point(53, 423);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(57, 16);
            this.label7.TabIndex = 16;
            this.label7.Text = "E ability:";
            // 
            // WtextBox
            // 
            this.WtextBox.Location = new System.Drawing.Point(166, 387);
            this.WtextBox.Name = "WtextBox";
            this.WtextBox.Size = new System.Drawing.Size(271, 22);
            this.WtextBox.TabIndex = 15;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Navy;
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label8.Location = new System.Drawing.Point(53, 387);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(61, 16);
            this.label8.TabIndex = 14;
            this.label8.Text = "W ability:";
            // 
            // DifficultytextBox
            // 
            this.DifficultytextBox.Location = new System.Drawing.Point(166, 496);
            this.DifficultytextBox.Name = "DifficultytextBox";
            this.DifficultytextBox.Size = new System.Drawing.Size(271, 22);
            this.DifficultytextBox.TabIndex = 21;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Navy;
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label9.Location = new System.Drawing.Point(53, 496);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(56, 16);
            this.label9.TabIndex = 20;
            this.label9.Text = "Difficulty";
            // 
            // RtextBox
            // 
            this.RtextBox.Location = new System.Drawing.Point(166, 460);
            this.RtextBox.Name = "RtextBox";
            this.RtextBox.Size = new System.Drawing.Size(271, 22);
            this.RtextBox.TabIndex = 19;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Navy;
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label10.Location = new System.Drawing.Point(53, 460);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(58, 16);
            this.label10.TabIndex = 18;
            this.label10.Text = "R ability:";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // RoletextBox
            // 
            this.RoletextBox.Location = new System.Drawing.Point(166, 536);
            this.RoletextBox.Name = "RoletextBox";
            this.RoletextBox.Size = new System.Drawing.Size(271, 22);
            this.RoletextBox.TabIndex = 23;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Navy;
            this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label12.Location = new System.Drawing.Point(53, 536);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(51, 16);
            this.label12.TabIndex = 22;
            this.label12.Text = "label12";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Navy;
            this.label11.Font = new System.Drawing.Font("MS PGothic", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(414, 58);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(467, 40);
            this.label11.TabIndex = 24;
            this.label11.Text = "LOL ANIMAL CHAMPION";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::FactoryProject.Properties.Resources.Background;
            this.ClientSize = new System.Drawing.Size(1191, 588);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.RoletextBox);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.DifficultytextBox);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.RtextBox);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.EtextBox);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.WtextBox);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.QtextBox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.PassivetextBox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.AnimaltextBox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.playertextBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.Createbutton);
            this.Controls.Add(this.usernametextBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.AnimalcomboBox);
            this.Name = "Form1";
            this.Text = "Animal Champion ";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox AnimalcomboBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox usernametextBox;
        private System.Windows.Forms.Button Createbutton;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox playertextBox;
        private System.Windows.Forms.TextBox AnimaltextBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox QtextBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox PassivetextBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox EtextBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox WtextBox;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox DifficultytextBox;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox RtextBox;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox RoletextBox;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
    }
}

